package com.itbuka.vip.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.itbuka.goods.domain.VipPointHistory;
import com.itbuka.vip.mapper.VipPointHistoryMapper;
import com.itbuka.vip.service.VipPointHistoryService;
import org.springframework.stereotype.Service;

/**
* @author 王庚润
* @description 针对表【vip_point_history】的数据库操作Service实现
* @createDate 2024-07-29 21:14:21
*/
@Service
public class VipPointHistoryServiceImpl extends ServiceImpl<VipPointHistoryMapper, VipPointHistory>
    implements VipPointHistoryService {

}




