package com.itbuka.vip.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController

public class VipPointHistoryController {
}
